package com.obra.model;

import jakarta.persistence.*;

@Entity
public class Parede {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private double comprimento;
    private double altura;
    private double espessura;
    private boolean possuiJanela;
    private boolean possuiPorta;

    @ManyToOne
    private Vertice inicio;

    @ManyToOne
    private Vertice fim;

    @ManyToOne
    @JoinColumn(name = "comodo_id")
    private Comodo comodo;

    public Parede() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public double getComprimento() { return comprimento; }
    public void setComprimento(double comprimento) { this.comprimento = comprimento; }

    public double getAltura() { return altura; }
    public void setAltura(double altura) { this.altura = altura; }

    public double getEspessura() { return espessura; }
    public void setEspessura(double espessura) { this.espessura = espessura; }

    public boolean isPossuiJanela() { return possuiJanela; }
    public void setPossuiJanela(boolean possuiJanela) { this.possuiJanela = possuiJanela; }

    public boolean isPossuiPorta() { return possuiPorta; }
    public void setPossuiPorta(boolean possuiPorta) { this.possuiPorta = possuiPorta; }

    public Vertice getInicio() { return inicio; }
    public void setInicio(Vertice inicio) { this.inicio = inicio; }

    public Vertice getFim() { return fim; }
    public void setFim(Vertice fim) { this.fim = fim; }

    public Comodo getComodo() { return comodo; }
    public void setComodo(Comodo comodo) { this.comodo = comodo; }
}
