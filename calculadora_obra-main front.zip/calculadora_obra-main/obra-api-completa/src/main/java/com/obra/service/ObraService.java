package com.obra.service;

import org.springframework.stereotype.Service;
import com.obra.dto.*;
import com.obra.model.Comodo;
import com.obra.model.Orcamento;
import com.obra.model.Parede;
import com.obra.repository.OrcamentoRepository;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

@Service
public class ObraService {

    private final OrcamentoRepository orcamentoRepository;

    public ObraService(OrcamentoRepository orcamentoRepository) {
        this.orcamentoRepository = orcamentoRepository;
    }

    // ---------- Cálculos originais (mantidos sem alteração de essência) ----------

    public double calcularConcreto(ConcretoDTO dto) {
        double total = 0;
        for (var p : dto.paredes) {
            total += dto.largura * dto.altura * p.comprimento;
        }
        return total;
    }

    public double calcularTijolos(TijoloDTO dto) {
        double area = 0;
        for (var p : dto.paredes) {
            area += p.altura * p.comprimento;
        }
        double areaTijolo = dto.tijolo.altura * dto.tijolo.largura;
        return area / areaTijolo;
    }

    // ---------- Etapa 1: submissão da planta e geração/persistência do orçamento ----------

    /**
     * Recebe a planta da casa (lista de cômodos) informada pelo usuário, calcula o
     * consumo de concreto e tijolos das paredes do perímetro de cada cômodo e
     * persiste o orçamento gerado, permitindo consulta posterior por número ou nome.
     */
    public OrcamentoResponseDTO gerarOrcamento(PlantaDTO plantaDTO) {
        if (plantaDTO.nomeUsuario == null || plantaDTO.nomeUsuario.isBlank()) {
            throw new IllegalArgumentException("O nome do usuário é obrigatório.");
        }
        if (plantaDTO.comodos == null || plantaDTO.comodos.isEmpty()) {
            throw new IllegalArgumentException("Informe ao menos um cômodo da planta.");
        }

        Orcamento orcamento = new Orcamento();
        orcamento.setNomeUsuario(plantaDTO.nomeUsuario);
        orcamento.setNumeroOrcamento(gerarNumeroOrcamento());
        orcamento.setDataCriacao(LocalDateTime.now());

        double volumeConcretoTotal = 0;
        double tijolosTotal = 0;
        double areaTijoloPadrao = 0.19 * 0.09; // tijolo cerâmico padrão (m)

        for (ComodoDTO comodoDTO : plantaDTO.comodos) {
            if (comodoDTO.largura <= 0 || comodoDTO.comprimento <= 0 || comodoDTO.altura <= 0) {
                throw new IllegalArgumentException(
                        "Dimensões inválidas para o cômodo: " + comodoDTO.nome);
            }

            Comodo comodo = new Comodo();
            comodo.setNome(comodoDTO.nome);
            comodo.setLargura(comodoDTO.largura);
            comodo.setComprimento(comodoDTO.comprimento);
            comodo.setAltura(comodoDTO.altura);

            // Perímetro do cômodo é representado por 4 paredes (retângulo)
            double[] comprimentos = {
                    comodoDTO.largura, comodoDTO.comprimento,
                    comodoDTO.largura, comodoDTO.comprimento
            };

            for (double comprimentoParede : comprimentos) {
                Parede parede = new Parede();
                parede.setComprimento(comprimentoParede);
                parede.setAltura(comodoDTO.altura);
                parede.setEspessura(comodoDTO.espessuraParede);
                parede.setPossuiJanela(comodoDTO.possuiJanela);
                parede.setPossuiPorta(comodoDTO.possuiPorta);
                comodo.adicionarParede(parede);

                volumeConcretoTotal += comprimentoParede * comodoDTO.altura * comodoDTO.espessuraParede;
                tijolosTotal += (comprimentoParede * comodoDTO.altura) / areaTijoloPadrao;
            }

            orcamento.adicionarComodo(comodo);
        }

        orcamento.setVolumeConcreto(volumeConcretoTotal);
        orcamento.setQtdTijolos(Math.ceil(tijolosTotal));

        Orcamento salvo = orcamentoRepository.save(orcamento);

        return new OrcamentoResponseDTO(
                salvo.getId(), salvo.getNumeroOrcamento(), salvo.getNomeUsuario(),
                salvo.getVolumeConcreto(), salvo.getQtdTijolos(),
                salvo.getComodos().size(), salvo.getDataCriacao());
    }

    public Optional<Orcamento> buscarPorNumero(String numeroOrcamento) {
        return orcamentoRepository.findByNumeroOrcamento(numeroOrcamento);
    }

    public List<Orcamento> buscarPorNomeUsuario(String nomeUsuario) {
        return orcamentoRepository.findByNomeUsuarioContainingIgnoreCase(nomeUsuario);
    }

    public List<Orcamento> listarTodos() {
        return orcamentoRepository.findAll();
    }

    private String gerarNumeroOrcamento() {
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS"));
        return "ORC-" + timestamp;
    }
}
