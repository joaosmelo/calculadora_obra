package com.obra.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "orcamento")
public class Orcamento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String numeroOrcamento;

    @Column(nullable = false)
    private String nomeUsuario;

    private double volumeConcreto;
    private double qtdTijolos;

    private LocalDateTime dataCriacao;

    @OneToMany(mappedBy = "orcamento", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Comodo> comodos = new ArrayList<>();

    public Orcamento() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNumeroOrcamento() { return numeroOrcamento; }
    public void setNumeroOrcamento(String numeroOrcamento) { this.numeroOrcamento = numeroOrcamento; }

    public String getNomeUsuario() { return nomeUsuario; }
    public void setNomeUsuario(String nomeUsuario) { this.nomeUsuario = nomeUsuario; }

    public double getVolumeConcreto() { return volumeConcreto; }
    public void setVolumeConcreto(double volumeConcreto) { this.volumeConcreto = volumeConcreto; }

    public double getQtdTijolos() { return qtdTijolos; }
    public void setQtdTijolos(double qtdTijolos) { this.qtdTijolos = qtdTijolos; }

    public LocalDateTime getDataCriacao() { return dataCriacao; }
    public void setDataCriacao(LocalDateTime dataCriacao) { this.dataCriacao = dataCriacao; }

    public List<Comodo> getComodos() { return comodos; }
    public void setComodos(List<Comodo> comodos) { this.comodos = comodos; }

    public void adicionarComodo(Comodo comodo) {
        comodo.setOrcamento(this);
        this.comodos.add(comodo);
    }
}
