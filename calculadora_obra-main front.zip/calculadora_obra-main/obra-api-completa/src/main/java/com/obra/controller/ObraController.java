package com.obra.controller;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import com.obra.dto.*;
import com.obra.model.Orcamento;
import com.obra.service.ObraService;

import java.util.List;

@RestController
@RequestMapping("/api/obra")
public class ObraController {

    private final ObraService service;

    public ObraController(ObraService service) {
        this.service = service;
    }

    @PostMapping("/concreto")
    public ApiResponse<Double> calcularConcreto(@RequestBody ConcretoDTO dto) {
        double result = service.calcularConcreto(dto);
        return new ApiResponse<>(true, "Volume calculado com sucesso", result);
    }

    @PostMapping("/tijolos")
    public ApiResponse<Double> calcularTijolos(@RequestBody TijoloDTO dto) {
        double result = service.calcularTijolos(dto);
        return new ApiResponse<>(true, "Quantidade calculada com sucesso", result);
    }

    // ---------- Etapa 1: submissão da planta / geração e consulta de orçamentos ----------

    @PostMapping("/orcamento")
    public ApiResponse<OrcamentoResponseDTO> gerarOrcamento(@RequestBody PlantaDTO plantaDTO) {
        OrcamentoResponseDTO resultado = service.gerarOrcamento(plantaDTO);
        return new ApiResponse<>(true, "Orçamento gerado com sucesso", resultado);
    }

    @GetMapping("/orcamento/numero/{numero}")
    public ApiResponse<Orcamento> buscarPorNumero(@PathVariable String numero) {
        return service.buscarPorNumero(numero)
                .map(o -> new ApiResponse<>(true, "Orçamento encontrado", o))
                .orElseGet(() -> new ApiResponse<>(false, "Orçamento não encontrado", null));
    }

    @GetMapping("/orcamento/usuario/{nome}")
    public ApiResponse<List<Orcamento>> buscarPorNomeUsuario(@PathVariable String nome) {
        List<Orcamento> resultado = service.buscarPorNomeUsuario(nome);
        boolean encontrou = !resultado.isEmpty();
        return new ApiResponse<>(encontrou,
                encontrou ? "Orçamento(s) encontrado(s)" : "Nenhum orçamento encontrado para este usuário",
                resultado);
    }

    @GetMapping("/orcamento")
    public ApiResponse<List<Orcamento>> listarTodos() {
        return new ApiResponse<>(true, "Lista de orçamentos", service.listarTodos());
    }

    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ApiResponse<Object> tratarErroValidacao(IllegalArgumentException ex) {
        return new ApiResponse<>(false, ex.getMessage(), null);
    }
}
