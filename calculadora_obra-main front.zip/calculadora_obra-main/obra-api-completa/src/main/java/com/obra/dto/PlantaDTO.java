package com.obra.dto;

import java.util.List;

public class PlantaDTO {

    public String nomeUsuario;
    public List<ComodoDTO> comodos;
}
