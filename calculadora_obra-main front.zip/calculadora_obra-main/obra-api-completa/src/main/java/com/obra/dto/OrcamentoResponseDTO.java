package com.obra.dto;

import java.time.LocalDateTime;

public class OrcamentoResponseDTO {

    public Long id;
    public String numeroOrcamento;
    public String nomeUsuario;
    public double volumeConcreto;
    public double qtdTijolos;
    public int quantidadeComodos;
    public LocalDateTime dataCriacao;

    public OrcamentoResponseDTO() {}

    public OrcamentoResponseDTO(Long id, String numeroOrcamento, String nomeUsuario,
                                 double volumeConcreto, double qtdTijolos,
                                 int quantidadeComodos, LocalDateTime dataCriacao) {
        this.id = id;
        this.numeroOrcamento = numeroOrcamento;
        this.nomeUsuario = nomeUsuario;
        this.volumeConcreto = volumeConcreto;
        this.qtdTijolos = qtdTijolos;
        this.quantidadeComodos = quantidadeComodos;
        this.dataCriacao = dataCriacao;
    }
}
