package com.obra.dto;

public class ComodoDTO {

    public String nome;
    public double largura;
    public double comprimento;
    public double altura;
    public double espessuraParede = 0.15;
    public boolean possuiJanela;
    public boolean possuiPorta;
}
