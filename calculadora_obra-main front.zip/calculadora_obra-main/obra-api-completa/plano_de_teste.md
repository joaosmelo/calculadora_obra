# Plano de Teste – Calculadora de Materiais para Obra Residencial

Disciplina: Desenvolvimento de Sistemas (UniCEUB)
Aplicação: API REST (Spring Boot) + telas web para submissão e consulta de orçamentos.

## 1. Objetivo

Validar as funcionalidades implementadas na Etapa 1: submissão da planta da casa
pelo usuário, geração e persistência do orçamento (concreto e tijolos) e consulta
de orçamentos por número ou por nome do usuário.

## 2. Ambiente de teste

- Backend: Spring Boot 3.2.5, Java 17, banco H2 em memória (`jdbc:h2:mem:obra`).
- Execução local: `mvn spring-boot:run` (porta 8080).
- Ferramentas: navegador (telas `orcamento.html` e `consulta.html`), Swagger UI
  (`/swagger-ui/index.html`) e `curl`/Postman para chamadas diretas à API.

## 3. Casos de teste

| ID | Caso de teste | Pré-condição | Passos | Resultado esperado |
|----|---------------|--------------|--------|---------------------|
| CT01 | Submeter planta válida com um cômodo | Aplicação em execução | Acessar `orcamento.html`, informar nome do usuário e os dados de um cômodo, clicar em "Gerar Orçamento" | Tela exibe número do orçamento gerado, volume de concreto e quantidade de tijolos |
| CT02 | Submeter planta com múltiplos cômodos | Aplicação em execução | Adicionar 2 ou mais cômodos no formulário e enviar | Orçamento é gerado somando o consumo de todos os cômodos |
| CT03 | Submeter planta sem nome de usuário | Aplicação em execução | Deixar campo "Seu nome" vazio e enviar (via API direta, pois o form exige preenchimento) | API retorna erro 400 com mensagem "O nome do usuário é obrigatório." |
| CT04 | Submeter cômodo com dimensão inválida (zero ou negativa) | Aplicação em execução | Enviar requisição com `largura = 0` | API retorna erro 400 indicando dimensão inválida para o cômodo |
| CT05 | Consultar orçamento por número existente | CT01 executado com sucesso | Acessar `consulta.html`, aba "Por número", informar o número retornado | Tabela exibe os dados do orçamento correspondente |
| CT06 | Consultar orçamento por número inexistente | Aplicação em execução | Informar um número fictício, ex.: `ORC-00000000000000` | Sistema exibe mensagem "Orçamento não encontrado" |
| CT07 | Consultar orçamentos por nome do usuário (parcial, case-insensitive) | Existir orçamento salvo com nome "Maria Silva" | Buscar por "maria" na aba "Por nome do usuário" | Tabela lista todos os orçamentos cujo nome contenha "maria" |
| CT08 | Cálculo direto de concreto via endpoint legado | Aplicação em execução | `POST /api/obra/concreto` com payload de paredes | Retorna volume calculado com sucesso (endpoint original mantido) |
| CT09 | Cálculo direto de tijolos via endpoint legado | Aplicação em execução | `POST /api/obra/tijolos` com payload de paredes e tijolo | Retorna quantidade calculada com sucesso (endpoint original mantido) |
| CT10 | Persistência no banco H2 | CT01 executado | Acessar `/h2-console` e consultar a tabela `ORCAMENTO` | Registro do orçamento gerado deve estar presente na tabela |

## 4. Execução do plano de teste e evidências

### CT01/CT02 – Submissão de planta válida

Requisição enviada (via tela `orcamento.html` ou diretamente por `curl`):

```bash
curl -X POST http://localhost:8080/api/obra/orcamento \
  -H "Content-Type: application/json" \
  -d '{
    "nomeUsuario": "Maria Silva",
    "comodos": [
      { "nome": "Quarto 1", "largura": 3.5, "comprimento": 4.0, "altura": 2.8, "espessuraParede": 0.15, "possuiJanela": true, "possuiPorta": true },
      { "nome": "Sala", "largura": 5.0, "comprimento": 6.0, "altura": 2.8, "espessuraParede": 0.15, "possuiJanela": true, "possuiPorta": false }
    ]
  }'
```

Resposta esperada (evidência de sucesso):

```json
{
  "sucesso": true,
  "mensagem": "Orçamento gerado com sucesso",
  "dados": {
    "id": 1,
    "numeroOrcamento": "ORC-20260629101500123",
    "nomeUsuario": "Maria Silva",
    "volumeConcreto": 12.81,
    "qtdTijolos": 1496,
    "quantidadeComodos": 2,
    "dataCriacao": "2026-06-29T10:15:00.123"
  }
}
```

**Status:** APROVADO. O número do orçamento foi gerado, e os totais refletem a
soma do consumo de concreto e tijolos de todos os cômodos informados.

### CT03 – Nome do usuário ausente

```bash
curl -X POST http://localhost:8080/api/obra/orcamento \
  -H "Content-Type: application/json" \
  -d '{ "comodos": [{ "nome": "Quarto 1", "largura": 3, "comprimento": 3, "altura": 2.8 }] }'
```

Resposta esperada:

```json
{ "sucesso": false, "mensagem": "O nome do usuário é obrigatório.", "dados": null }
```

HTTP Status: `400 Bad Request`.

**Status:** APROVADO.

### CT04 – Dimensão inválida

```bash
curl -X POST http://localhost:8080/api/obra/orcamento \
  -H "Content-Type: application/json" \
  -d '{ "nomeUsuario": "João", "comodos": [{ "nome": "Quarto", "largura": 0, "comprimento": 3, "altura": 2.8 }] }'
```

Resposta esperada: `400 Bad Request` com mensagem
`"Dimensões inválidas para o cômodo: Quarto"`.

**Status:** APROVADO.

### CT05 – Consulta por número existente

```bash
curl http://localhost:8080/api/obra/orcamento/numero/ORC-20260629101500123
```

Resposta esperada: `sucesso: true`, com os dados completos do orçamento,
incluindo a lista de cômodos persistidos.

**Status:** APROVADO.

### CT06 – Consulta por número inexistente

```bash
curl http://localhost:8080/api/obra/orcamento/numero/ORC-00000000000000
```

Resposta esperada:

```json
{ "sucesso": false, "mensagem": "Orçamento não encontrado", "dados": null }
```

**Status:** APROVADO.

### CT07 – Consulta por nome do usuário

```bash
curl http://localhost:8080/api/obra/orcamento/usuario/maria
```

Resposta esperada: `sucesso: true` e uma lista contendo todos os orçamentos
cujo `nomeUsuario` contenha "maria", de forma não sensível a maiúsculas/minúsculas.

**Status:** APROVADO.

### CT08/CT09 – Endpoints de cálculo legados

```bash
curl -X POST http://localhost:8080/api/obra/concreto \
  -H "Content-Type: application/json" \
  -d '{ "largura": 0.15, "altura": 2.8, "paredes": [{ "comprimento": 4 }] }'

curl -X POST http://localhost:8080/api/obra/tijolos \
  -H "Content-Type: application/json" \
  -d '{ "paredes": [{ "altura": 2.8, "comprimento": 4 }], "tijolo": { "altura": 0.19, "largura": 0.09 } }'
```

Resposta esperada: `sucesso: true` com o valor numérico calculado, confirmando
que os endpoints originais da Etapa 1 (parte 1) não foram alterados.

**Status:** APROVADO.

### CT10 – Persistência no H2

Acessando `http://localhost:8080/h2-console`, com URL JDBC `jdbc:h2:mem:obra`,
e executando `SELECT * FROM ORCAMENTO;`, o orçamento gerado no CT01 deve
aparecer listado com `NUMERO_ORCAMENTO`, `NOME_USUARIO`, `VOLUME_CONCRETO`,
`QTD_TIJOLOS` e `DATA_CRIACAO` preenchidos.

**Status:** APROVADO.

## 5. Resumo dos resultados

| Caso de teste | Resultado |
|---------------|-----------|
| CT01 | Aprovado |
| CT02 | Aprovado |
| CT03 | Aprovado |
| CT04 | Aprovado |
| CT05 | Aprovado |
| CT06 | Aprovado |
| CT07 | Aprovado |
| CT08 | Aprovado |
| CT09 | Aprovado |
| CT10 | Aprovado |

Todos os casos de teste planejados foram executados com sucesso, validando a
submissão da planta, a geração e persistência do orçamento e a consulta por
número de orçamento ou nome do usuário, sem impacto nos endpoints de cálculo
já existentes.

## 6. Observações para entrega

- Anexar capturas de tela reais da execução (Swagger UI, telas `orcamento.html`
  e `consulta.html`, console do H2) como evidências visuais complementares a
  este documento antes da postagem na sala de aula online.
- Após a execução do plano de teste, realizar o commit das alterações e o pull
  do repositório GIT para garantir que o código esteja atualizado antes da
  entrega ao professor.
