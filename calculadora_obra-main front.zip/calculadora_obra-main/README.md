# calculadora_obra

Calculadora de Materiais para Obra Residencial — API REST (Spring Boot) com
telas web para submissão e consulta de orçamentos de concreto e tijolos.

## Estrutura

O projeto está em `obra-api-completa/` (Maven, Java 17, Spring Boot 3.2.5, H2).

## Como executar

```bash
cd obra-api-completa
mvn spring-boot:run
```

A aplicação inicia em `http://localhost:8080`.

- Tela inicial: `http://localhost:8080/index.html`
- Solicitar orçamento (envio da planta da casa): `http://localhost:8080/orcamento.html`
- Consultar orçamento (por número ou nome do usuário): `http://localhost:8080/consulta.html`
- Swagger UI: `http://localhost:8080/swagger-ui/index.html`
- Console do banco H2: `http://localhost:8080/h2-console` (JDBC URL: `jdbc:h2:mem:obra`)

## Funcionalidades (Etapa 1)

- **Submissão da planta da casa:** o usuário informa, cômodo por cômodo, as
  dimensões (largura, comprimento, altura, espessura da parede) e se há porta
  ou janela. A tela permite adicionar/remover cômodos dinamicamente.
- **Persistência do orçamento:** cada solicitação gera um orçamento com número
  único (`ORC-<timestamp>`), nome do usuário, volume de concreto e quantidade
  de tijolos calculados, salvos no banco H2 junto com os cômodos e paredes.
- **Consulta de orçamentos:** é possível buscar um orçamento pelo número
  exato ou listar orçamentos por nome do usuário (busca parcial,
  case-insensitive).
- Os endpoints de cálculo originais (`/api/obra/concreto` e
  `/api/obra/tijolos`) permanecem inalterados.

Veja `obra-api-completa/plano_de_teste.md` para o plano de teste e as
evidências de execução.
